# Smart Prosthetic Knee — STM32U585 Firmware

Production-grade firmware for a hydraulic prosthetic knee, built on
**STM32U585AI** (B-U585I-IOT02A Discovery Kit) with **FreeRTOS**.

---

## Repository layout

```
ProstheticKnee/
├── Core/
│   ├── Inc/
│   │   ├── FreeRTOSConfig.h         FreeRTOS tuning
│   │   └── stm32u5xx_it.h           ISR prototypes only
│   └── Src/
│       ├── main.c                   Boot + manual peripheral init
│       ├── stm32u5xx_it.c           ISR + FreeRTOS hook overrides
│       ├── startup_stm32u585.s      Vector table + reset
│       └── stm32u585.ld             Linker script
├── Application/
│   ├── Inc/
│   │   ├── project_types.h          Fixed-width types + telemetry struct
│   │   ├── packet_protocol.h        Start/Len/Payload/Cmd/CRC/Stop
│   │   ├── filter_lib.h             Moving Avg + IIR + EMA
│   │   ├── adc_manager.h            Internal ADC, DMA, oversampling
│   │   ├── motor_control.h          Dual DC motor + PWM ramp
│   │   ├── uart_dma.h               USART1/2 with idle-DMA
│   │   ├── bluetooth.h              50 Hz telemetry task
│   │   ├── state_machine.h          Gait FSM
│   │   ├── safety.h                 Watchdog + heartbeat monitor
│   │   └── app_tasks.h              Task priorities + prototypes
│   └── Src/                          (matching .c files)
├── Third_Party/
│   └── FreeRTOS/                    Kernel + portable layer
│       ├── Source/include/          *.h headers (copy from V10.x)
│       ├── Source/{tasks,queue,list,…}.c
│       └── Source/portable/
│           ├── GCC/ARM_CM33_NTZ/   port.c + portasm.s
│           └── MemMang/heap_4.c     coalescing allocator
├── Drivers/
│   ├── STM32U5xx_HAL_Driver/        (copy from STM32CubeU5 pack)
│   └── CMSIS/                       (copy from CMSIS V5.9 pack)
├── Docs/
│   ├── ARCHITECTURE.md              System overview
│   ├── MODULE_REFERENCE.md          File-by-file walkthrough
│   └── LESSON_1_UART_FUNDAMENTALS.md  Lecture notes for AI tutor
├── Tests/
│   ├── host_test.c                  Offline unit tests
│   └── Makefile
├── Makefile                         ARM build (offline-friendly)
└── README.md                        this file
```

---

## Quick start

### 1. Pull the dependencies

On the **internet-connected** PC:

```bash
# FreeRTOS kernel V10.x
git clone https://github.com/FreeRTOS/FreeRTOS-Kernel.git
cp -r FreeRTOS-Kernel/include            ProstheticKnee/Third_Party/FreeRTOS/Source/
cp  FreeRTOS-Kernel/{tasks,queue,list,timers,event_groups,stream_buffer}.c \
                                                  ProstheticKnee/Third_Party/FreeRTOS/Source/
cp -r FreeRTOS-Kernel/portable/GCC/ARM_CM33_NTZ \
                                ProstheticKnee/Third_Party/FreeRTOS/Source/portable/GCC/
cp  FreeRTOS-Kernel/portable/MemMang/heap_4.c \
                                ProstheticKnee/Third_Party/FreeRTOS/Source/portable/MemMang/

# STM32CubeU5 HAL pack
# Download from st.com → STM32CubeU5, then:
cp -r STM32Cube_FW_U5_V*/Drivers/STM32U5xx_HAL_Driver ProstheticKnee/Drivers/
cp -r STM32Cube_FW_U5_V*/Drivers/CMSIS               ProstheticKnee/Drivers/
```

Move the whole folder over USB to the offline workstation.

### 2. Run offline tests

```bash
cd Tests
make
./host_test
```

Expected:

```
CRC8("123456789") = 0xF4 (expect 0xF4)
Packet round-trip OK
CRC corruption correctly rejected
Moving average OK
EMA Q15 OK
ALL TESTS PASSED
```

### 3. Build firmware

```bash
make            # build ProstheticKnee.elf
make size       # show section sizes
```

### 4. Flash to board

```bash
make flash
```

---

## Telemetry wire format

```
 0xAA   LEN   <LEN bytes>   CMD   CRC8   0x55
```

Payload layout:

| Off | Size | Field        | Type     | Range        |
|-----|------|--------------|----------|--------------|
|  0  |  1   | spool_angle  | uint8_t  | 0..100       |
|  1  |  2   | force        | int16_t  | ±200         |
|  3  |  2   | knee_angle   | int16_t  | ±200         |
|  5  |  2   | moment       | int16_t  | ±3000        |
|  7  |  1   | state_id     | uint8_t  | 0..16        |
|  8  |  2   | battery_mv   | uint16_t | 0..5000      |

CRC-8 with poly 0x07, init 0x00, no reflection.
Known answer: `CRC8("123456789") = 0xF4`.

---

## Further reading

* `Docs/ARCHITECTURE.md` — full system architecture, state diagrams,
  memory budget.
* `Docs/MODULE_REFERENCE.md` — file-by-file explanation, written as
  if teaching the codebase to a new engineer.
* `Docs/LESSON_1_UART_FUNDAMENTALS.md` — lecture notes for an AI
  tutor (NotebookLM-friendly).

---

## License

Application code: MIT.
FreeRTOS: MIT (see `Third_Party/FreeRTOS/`).
STM32 HAL drivers: BSD-3-Clause (see `Drivers/STM32U5xx_HAL_Driver/`).
